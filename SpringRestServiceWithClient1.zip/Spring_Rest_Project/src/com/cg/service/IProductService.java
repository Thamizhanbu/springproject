package com.cg.service;

import java.util.List;

import com.cg.model.Product;

public interface IProductService {

	public List<Product> getAllProducts();

	public void addProduct(Product product);
}
