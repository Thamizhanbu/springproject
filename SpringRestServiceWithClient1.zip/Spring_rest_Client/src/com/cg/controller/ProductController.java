package com.cg.controller;

import java.io.IOException;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.cg.model.Product;

@Controller
public class ProductController {

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String addproduct(@RequestParam Map<String, String> map, Model model) throws IOException {

		int id = Integer.parseInt(map.get("id"));
		String name = map.get("name");
		double price = Double.parseDouble(map.get("price"));

		Product product = new Product(id, name, price);

		RestTemplate restTemplate = new RestTemplate();
		/*
		 * restTemplate.getMessageConverters().add(new
		 * MappingJacksonHttpMessageConverter());
		 * restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
		 */

		String uri = "http://localhost:8787/Spring_Rest_Project/rest/create";

		Product product2 = restTemplate.postForObject(uri, product, Product.class);

		JSONObject object = new JSONObject();
		try {
			object.append("price", product2.getProductPrice());
			object.append("name", product2.getProductName());
			object.append("id", product2.getProductId());
		} catch (JSONException e) {
			e.printStackTrace();
		}

		model.addAttribute("jsonData", object);

		return "success";

	}

}
