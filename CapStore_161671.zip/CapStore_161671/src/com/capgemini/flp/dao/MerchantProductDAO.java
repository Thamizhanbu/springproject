package com.capgemini.flp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.flp.dto.MerchantProduct;

public interface MerchantProductDAO extends JpaRepository<MerchantProductDAO, Integer> {
	
	@Query("select m from Merchants m where m.emailId=?1 ")
	MerchantProduct findMerchantProduct(String emailId);

}
