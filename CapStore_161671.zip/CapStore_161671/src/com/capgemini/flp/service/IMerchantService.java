package com.capgemini.flp.service;

import java.util.List;

import com.capgemini.flp.dto.Merchants;
import com.capgemini.flp.exception.MerchantException;

public interface IMerchantService {
	
	public String addMerchant(String emailId) throws MerchantException;
	public String removeMerchant(String emailId) throws MerchantException;
	public String inviteMerchant(String emailId) throws MerchantException;
	public List<Merchants> findAllMerchants() throws MerchantException;

}
