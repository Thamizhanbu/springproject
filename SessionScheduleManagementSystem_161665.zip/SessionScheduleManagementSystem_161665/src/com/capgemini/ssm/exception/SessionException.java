package com.capgemini.ssm.exception;

public class SessionException extends Exception{
	private String message;
	
	public SessionException() {
		
	}
	
	public SessionException(String message) {
		this.message=message;
	}

	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		return "UserException [message=" + message + "]";
	}
	
	
}
