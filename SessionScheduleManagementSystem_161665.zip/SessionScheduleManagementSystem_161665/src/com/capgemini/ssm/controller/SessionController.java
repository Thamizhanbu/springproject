package com.capgemini.ssm.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.capgemini.ssm.exception.SessionException;
import com.capgemini.ssm.model.ScheduledSessions;
import com.capgemini.ssm.service.IScheduledSessionsManagement;
import java.util.List;


//this is the controller declaration

@Controller
@RequestMapping(value="/session")
public class SessionController {
	@Autowired
	private IScheduledSessionsManagement sessionService;
	
	
	
	//this method is to fetch the table details and to display in the jsp page 
	
	@RequestMapping(value="/view", method=RequestMethod.GET)
	public ModelAndView getScheduledSessions() {
		try {
			List<ScheduledSessions> scheduledsessionsList=sessionService.getScheduledSessions();
			if(scheduledsessionsList.size()!=0) {				
				return new ModelAndView("ScheduledSessions","sessionList",scheduledsessionsList);
			}else {
				return new ModelAndView("Exception","Exception","No users in database");
			}
		}catch(SessionException e) {
			return new ModelAndView("status","status",e.getMessage());
		}
	}
	
	

	
	
	// this method is to fetch the session name from the table and display in the success page

	@RequestMapping(value="/enroll", method=RequestMethod.GET)
	public ModelAndView sessionEnrollment(@RequestParam(value="id") Integer id)  {

		try{
		String sessionName = sessionService.getSessionName(id);
		return new ModelAndView("Success","sessionName",sessionName);
		}
	catch(SessionException e) {
		return new ModelAndView("Exception","Exception",e.getMessage());
	}
	}

	
	

	
	
}
