package com.capgemini.ssm.dao;

import java.util.List;
import com.capgemini.ssm.exception.SessionException;
import com.capgemini.ssm.model.ScheduledSessions;

public interface IScheduledSessionsManagementDao {

	public abstract List<ScheduledSessions> getScheduledSessions() throws SessionException;

	public abstract String getSessionName(int id)  throws SessionException;
	
}
