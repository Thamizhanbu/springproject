package com.capgemini.ssm.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import com.capgemini.ssm.exception.SessionException;
import com.capgemini.ssm.model.ScheduledSessions;


@Repository
public class ScheduledSessionsManagementDaoImplementation implements IScheduledSessionsManagementDao{
	@PersistenceContext
	private EntityManager entityManager;
	

	@Override
	public List<ScheduledSessions> getScheduledSessions() throws SessionException {
		String sql="Select scheduledsessions from ScheduledSessions scheduledsessions";
		try {
			Query query=entityManager.createQuery(sql);
			List<ScheduledSessions> user=query.getResultList();			
			return user;
		}catch(PersistenceException e) {			
			throw new SessionException(e.getMessage());
		}catch(Exception e) {	
			throw new SessionException(e.getMessage());
		}

	}
	@Override
	public String getSessionName(int id)  throws SessionException {
		
		String sql="Select scheduledsessions.name from ScheduledSessions scheduledsessions where scheduledsessions.id = :pid";
		Query query=entityManager.createQuery(sql);
		query.setParameter("pid", id);
		String sessionName = (String) query.getSingleResult();
		return sessionName;
	}


}
