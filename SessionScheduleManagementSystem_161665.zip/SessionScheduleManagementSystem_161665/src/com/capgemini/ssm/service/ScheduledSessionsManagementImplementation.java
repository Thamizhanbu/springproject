package com.capgemini.ssm.service;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.capgemini.ssm.dao.IScheduledSessionsManagementDao;
import com.capgemini.ssm.exception.SessionException;
import com.capgemini.ssm.model.ScheduledSessions;



@Service
@Transactional
public class ScheduledSessionsManagementImplementation implements IScheduledSessionsManagement{

	@Autowired
	private IScheduledSessionsManagementDao sessionDAO;

	
	@Override
	public List<ScheduledSessions> getScheduledSessions() throws SessionException {
		try {

				return sessionDAO.getScheduledSessions();
			}

		catch(Exception e) {
			throw new SessionException(e.getMessage());
		}
		
	}

@Override
	public String getSessionName(int id) throws SessionException {
try{	
	return sessionDAO.getSessionName(id);
}

catch(Exception e) {
	throw new SessionException(e.getMessage());
}
	}
	
}
