package com.capgemini.ssm.service;

import java.util.List;
import com.capgemini.ssm.exception.SessionException;
import com.capgemini.ssm.model.ScheduledSessions;

public interface IScheduledSessionsManagement {

	public abstract List<ScheduledSessions> getScheduledSessions() throws SessionException;

	public abstract String getSessionName(int id) throws SessionException;

}
