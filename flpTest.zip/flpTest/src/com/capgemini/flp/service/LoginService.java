package com.capgemini.flp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.flp.dao.ILoginDAO;
import com.capgemini.flp.exception.LoginException;

@Service
public class LoginService implements ILoginService {

	@Autowired
	private ILoginDAO dao;

	public boolean findUser(String emailId,String password) throws LoginException{
		return dao.findUser(emailId,password);
	}
	@Override
	public boolean findAdmin(String emailId, String password)
			throws LoginException {
		return dao.findAdmin(emailId,password);
	}
	@Override
	public boolean findMerchant(String emailId, String password)
			throws LoginException {
		return dao.findMerchant(emailId,password);
	}

}
