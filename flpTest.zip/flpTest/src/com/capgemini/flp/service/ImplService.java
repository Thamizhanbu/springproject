package com.capgemini.flp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.flp.dao.IntDAO;
import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Feedback;
import com.capgemini.flp.exception.FeedbackException;


@Service
@Transactional
public class ImplService implements IntService {
@Autowired
IntDAO dao;
	@Override
	public boolean getFeedbackPage(Feedback feedback) throws FeedbackException{
		
		return dao.getFeedbackPage(feedback);
	}

}
