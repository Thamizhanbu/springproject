package com.capgemini.flp.service;



import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Service	
public interface IMerchantService {
	
/*	public String addMerchant(String emailId) throws MerchantException;
	public String removeMerchant(String emailId) throws MerchantException;
	public String inviteMerchant(String emailId) throws MerchantException;
	public List<Merchant> findAllMerchants() throws MerchantException;*/
	public void removeMerchantProducts(String emailId);

}
