package com.capgemini.flp.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="merchant_login")
public class Merchant {

	@Id
	@Column(name="email_Id")
	private String emailId;
	@NotNull
	private String password;
	private Long phoneNumber;
	private String name;
	private String address;
	@Column(name="Organization_name")
	private String organizationname;


	//getters and setters
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getOrganizationname() {
		return organizationname;
	}
	public void setOrganizationname(String organizationname) {
		this.organizationname = organizationname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	public Long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Merchant [emailId=" + emailId + ", password=" + password
				+ ", phoneNumber=" + phoneNumber + ", name=" + name
				+ ", address=" + address + ", organizationname="
				+ organizationname + "]";
	}


}
