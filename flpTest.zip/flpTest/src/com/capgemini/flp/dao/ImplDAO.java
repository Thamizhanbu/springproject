package com.capgemini.flp.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Repository;


import com.capgemini.flp.dto.Feedback;
import com.capgemini.flp.exception.FeedbackException;


@Repository
public class ImplDAO implements IntDAO {

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public boolean getFeedbackPage(Feedback feedback)throws FeedbackException {
		try
		{
		entityManager.persist(feedback);
		return true;
	}catch(PersistenceException e) {
		throw new FeedbackException(e.getMessage());
	}
}
}
