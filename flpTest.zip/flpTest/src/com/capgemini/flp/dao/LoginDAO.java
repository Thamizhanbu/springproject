package com.capgemini.flp.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Repository;

import com.capgemini.flp.exception.LoginException;
import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.dto.Customer;

@Configuration
@Repository
public class LoginDAO implements ILoginDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public boolean findUser(String emailId, String password)
			throws LoginException {
		boolean flag=false;
		try{	
			Customer customer=entityManager.find(Customer.class, emailId);
		System.err.println(customer);
	if(customer != null)
		{
			if(emailId.equals(customer.getEmailId()) && password.equals(customer.getPassword())){
				flag=true;
			}
			else
			{
				flag=false;
			}
		}
		else
		{
			flag=false;
		}
		}catch(PersistenceException e){
			throw new LoginException(e.getMessage());
		}
		return flag;
	}

	@Override
	public boolean findAdmin(String emailId, String password)
			throws LoginException {
		boolean flag=false;
		try{	
		Admin admin=entityManager.find(Admin.class, emailId);
		System.err.println(admin);
	if(admin != null)
		{
			if(emailId.equals(admin.getEmailId()) && password.equals(admin.getPassword())){
				flag=true;
			}
			else
			{
				flag=false;
			}
		}
		else
		{
			flag=false;
		}
		}catch(PersistenceException e){
			throw new LoginException(e.getMessage());
		}
		return flag;
	}

	@Override
	public boolean findMerchant(String emailId, String password)
			throws LoginException {
		boolean flag=false;
		try{	
		Merchant merchant=entityManager.find(Merchant.class, emailId);
		System.err.println(merchant);
	if(merchant != null)
		{
			if(emailId.equals(merchant.getEmailId()) && password.equals(merchant.getPassword())){
				flag=true;
			}
			else
			{
				flag=false;
			}
		}
		else
		{
			flag=false;
		}
		}catch(PersistenceException e){
			throw new LoginException(e.getMessage());
		}
		return flag;
	}
	}
	
