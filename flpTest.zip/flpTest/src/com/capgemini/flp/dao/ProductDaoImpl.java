package com.capgemini.flp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.flp.dto.Merchant_Product;
import com.capgemini.flp.exception.ProductException;

@Repository
public class ProductDaoImpl implements IProductDao {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<Merchant_Product> getProducts() throws ProductException {
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("from Merchant_Product",Merchant_Product.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Merchant_Product> getElectronicProducts() throws ProductException {
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select m from Merchant_Product m where m.productCategory='Electronics'",Merchant_Product.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Merchant_Product> getFashionProducts() throws ProductException {
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select m from MerchantProduct m where m.productCategory='Fashion' or m.productCategory='fashion' ",Merchant_Product.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Merchant_Product> getFurnitureProducts() throws ProductException {
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select m from MerchantProduct m where m.productCategory='Furniture' or m.productCategory='furniture' ",Merchant_Product.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Merchant_Product> getSportsBooksAndMoreProducts() throws ProductException {
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select m from MerchantProduct m where m.productCategory='sports' or m.productCategory='books' or m.productCategory='more' ",Merchant_Product.class);
			System.out.println("jdhygfi");
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public Merchant_Product getProduct(String product) throws ProductException {
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select m from MerchantProduct m where m.productName='"+product+"'",Merchant_Product.class);
			return query.getSingleResult();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Merchant_Product> getProductsAsc(String name) throws ProductException {
	
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select m from MerchantProduct m where m.productCategory='"+name+"' order by m.productPrice ASC",Merchant_Product.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public List<Merchant_Product> getProductDesc(String category) throws ProductException {
          
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select m from MerchantProduct m where m.productCategory='"+category+"' order by m.productPrice DESC",Merchant_Product.class);
			return query.getResultList();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}

	@Override
	public Merchant_Product getProductDetails(int id) throws ProductException {
		try{
			TypedQuery<Merchant_Product> query=entityManager.createQuery("select m.productQuantity from MerchantProduct m where m.productId='"+id+"' ",Merchant_Product.class);
			System.out.println("hi");
			return query.getSingleResult();
			}catch(Exception e){
				throw new ProductException(e.getMessage());
			}
	}
	
}
