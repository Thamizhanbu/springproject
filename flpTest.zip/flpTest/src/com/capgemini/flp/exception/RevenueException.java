package com.capgemini.flp.exception;

public class RevenueException extends Exception {
private static final long serialVersionUID = 1L;
	
	public String msg;
	public RevenueException(String msg) {
		this.msg = msg;
	}
	
	public String getMessage() {
		return msg;
	}
}
