package com.capgemini.flp.exception;

public class SignUpException extends Exception {
	private static final long serialVersionUID = 1L;
	private String status;
	
	public SignUpException()
	{
		this.status="Unable to perform operation";
	}
	public  SignUpException(String status)
	{
		super(status);
	}
	
	public String getStatus() {
		return status;
	}
	
	@Override
	public String toString() {
		return "SignUpException [status=" + status + "]";
	}
	
}
